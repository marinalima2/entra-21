﻿using Entra21.BancoDados01.Ado.Net.Models;

namespace Entra21.BancoDados01.Ado.Net.Services
{
    internal interface IEditoraService
    {
        List<Editora> ObterTodos();

    }
}
